public class EjercicioClase2 {
    public static void main(String[] args) {
        
   ListaEnlazada miLista = new ListaEnlazada();

   //Agregando elementos a la lista
   miLista.agregar(1);
   miLista.agregar(2);
   miLista.agregar(3);
   miLista.agregar(4);

   System.out.println(" Lista despues de agregar elementos: ");
   miLista.imprimir(); // Salida: 1 -> 2 -> 3 -> 4 -> null

   //Eliminando un elemento
   miLista.agregar(2);
   System.out.println(" Lista despues de agregar 2: ");
   miLista.imprimir(); // Salida: 1 -> 2 -> 3 -> 4 -> null


    }
}
