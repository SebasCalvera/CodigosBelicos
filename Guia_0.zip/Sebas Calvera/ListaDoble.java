public class ListaDoble {
    NodoDoble cabeza;
    NodoDoble cola;

    public ListaDoble() {
        this.cabeza = null;
        this.cola = null;
    }

    // Método para insertar un nodo al inicio de la lista
    public void insertarAlInicio(int valor) 

    // Método para insertar un nodo al final de la lista
    public void insertarAlFinal(int valor) 

    // Método para eliminar un nodo
    public void eliminar(int valor) 

    // Método para buscar un nodo
    public boolean buscar(int valor) 

    // Mostrar de adelante hacia atrás
    public void mostrarAdelante() 

    // Mostrar de atrás hacia adelante
    public void mostrarAtras() 

    public static void main(String[] args) {
     
}
