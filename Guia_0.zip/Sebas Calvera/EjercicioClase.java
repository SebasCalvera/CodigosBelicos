import java.util.Arrays;        

public class EjercicioClase {

  
   public static void main(String[] args) {
    //Ejemplo de arreglo estatico
    double[] calificaciones = new double [8]; ///Arreglo de 8 decimales
    calificaciones [0] = 6.8;
    calificaciones [1] = 8.3;
    calificaciones [2] = 10;
    calificaciones [3] = 9.5;
    calificaciones [4] = 4.5;
    calificaciones [5] = 7.7;
    calificaciones [6] = 9.4;
    calificaciones [7] = 10;
   
System.out.println(Arrays.toString(calificaciones));
    

   }
    
}


